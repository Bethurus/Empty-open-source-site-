<p align=center>
  <img src="./assets/images/empty.png"/>
</p>
<h2 align=center>Clique <a href="https://empty.wtf/">aqui</a> para ver a live demo.</h2>

## O que é?

É uma landing page feita para um produto de Minecraft, mostrando o mesmo e informando mais sobre.

## Tecnologias usadas

-   [x] HTML
-   [x] CSS
-   [x] JS
-   [x] Bootstrap


